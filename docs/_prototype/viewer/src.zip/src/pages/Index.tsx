import { ViewerApp } from '@/components/viewer/ViewerApp';

const Index = () => {
  return <ViewerApp />;
};

export default Index;
